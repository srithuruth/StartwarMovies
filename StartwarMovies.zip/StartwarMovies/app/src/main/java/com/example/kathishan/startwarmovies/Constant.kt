package com.example.kathishan.startwarmovies


const val BASE_URL = "https://swapi.co/api/films/"
