package com.example.kathishan.startwarmovies

data class Response(val title: String)